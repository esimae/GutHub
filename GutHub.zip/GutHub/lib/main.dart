import 'package:flutter/material.dart';

import 'package:cookbook/app.dart';

void main() => runApp(
      new RecipesApp(),
    );
